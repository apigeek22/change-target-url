var newTargetUrl = "http://mocktarget.apigee.net/user?user=FrodoBaggins"
context.setVariable("newTargetUrl",newTargetUrl);