var newTargetUrl = "https://mocktarget.apigee.net/user?user=FrodoBaggins"
context.setVariable("target.url",newTargetUrl);